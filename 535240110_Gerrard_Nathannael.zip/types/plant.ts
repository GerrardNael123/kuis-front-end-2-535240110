export interface Plant {
  id: string;
  name: string;
  type: string;
  lastWatered: string;
  wateringSchedule: number; // hari
  careNotes: string[];
  photo?: string;
}

export type PlantFormData = Omit<Plant, 'id'>;