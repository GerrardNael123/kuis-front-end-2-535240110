import PlantList from '@/components/PlantList';

export default function PlantsPage() {
  return (
    <div className="container mt-4">
      <PlantList />
    </div>
  );
}